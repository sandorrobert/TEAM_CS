package com.example.kolcsonzo.Classes;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Connector {

    Connection con = null;

    public Connector(String database, String username, String password, String ipAddress){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://"+ipAddress+":3306/"+database+"",username,password);


        }catch(Exception e){

        }
    }

    public void stopConnection(){
        try{
            con.close();
        }
        catch(Exception e){
            System.out.println(e);
        }
    }

    public ResultSet getInfoFromDatabase(String sqlQuery) {
        ResultSet rs = null;
        try {
            Statement stmt = con.createStatement();
            rs = stmt.executeQuery(sqlQuery);
        } catch (Exception e) {

        }
        return rs;
    }

    public int setInfoToDatabase(String sqlQuery) {
        int valasz = 0;
        try {
            Statement stmt = con.createStatement();
            valasz = stmt.executeUpdate(sqlQuery);
        } catch (Exception e) {

        }
        return valasz;
    }

}