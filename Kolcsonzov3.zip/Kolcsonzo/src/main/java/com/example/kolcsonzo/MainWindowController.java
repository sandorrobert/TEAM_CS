package com.example.kolcsonzo;

import com.example.kolcsonzo.Classes.Connector;
import com.example.kolcsonzo.Classes.Jatekok;
import com.example.kolcsonzo.Classes.Rents;
import com.example.kolcsonzo.Classes.Users;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import com.example.kolcsonzo.Classes.Process;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class MainWindowController implements Initializable {

    Connector connector = new Connector("konzolbolt", "root", "", "localhost");

    Process proc;

    public TableView<Jatekok> jatekokTable;
    public TableColumn<Jatekok, String> col_jatek_nev;
    public TableColumn<Jatekok, Integer> col_jatek_kor;
    public TableColumn<Jatekok, String> col_jatek_platf;
    public TableColumn<Jatekok, String> col_jatek_kat;
    public TableColumn<Jatekok, String> col_jatek_eler;
    public TableView<Rents> kolcsonzesTable;
    public TableColumn<Rents, String> col_kolcson_jatek;
    public TableColumn<Rents, String> col_kolcson_kolcson;
    public TableColumn<Rents, String> col_kolcson_email;
    public TableColumn<Rents, String> col_kolcson_kolcs_datum;
    public TableColumn<Rents, String> col_kolcson_napok;
    public TableColumn<Rents, String> col_kolcson_lejart;
    public ComboBox<Users> kolcsonzoComboBox;
    public MenuItem mainCloseButton;
    ObservableList KolcsonzoList;
    ObservableList<Jatekok> jatekokList;
    ObservableList<Rents> KolcsonzesekList;

    public TextField searchJatekInput = new TextField();
    public TextField searchKolcsonzesInput = new TextField();


    //usually list of combobox items here


    @FXML
    protected void onKolcsonzes(){
        int temp = jatekokTable.getSelectionModel().getSelectedIndex();
        int temp2 = kolcsonzoComboBox.getSelectionModel().getSelectedIndex();
        if(temp>=0){
            if(temp2>0){
                Jatekok jatek = jatekokTable.getSelectionModel().getSelectedItem();
                String selected = String.valueOf(kolcsonzoComboBox.getValue());
                String[] splitted = selected.split(";");
                if(proc.isOldEnough(jatek.getKorhatar(),splitted[1])) {
                    int userID = proc.searchUserID(splitted[1]);
                    if (!proc.searchTartozas(splitted[1])) {
                        int napok = 0;
                        Optional<String> textInputResut;
                        boolean cancelled;
                        boolean isNumber;


                        do {
                            cancelled = false;
                            isNumber = false;
                            TextInputDialog textInput = new TextInputDialog();
                            textInput.setHeaderText("Kérem a kölcsönzött napok számát.");
                            textInput.setTitle("Kölcsönzött napok");
                            textInputResut = textInput.showAndWait();
                            if (textInputResut.isPresent()) {
                                isNumber = isNumeric(textInputResut.get());
                                if (isNumber) {
                                    napok = Integer.parseInt(textInputResut.get());
                                    break;
                                }
                            } else {
                                cancelled = true;
                                break;
                                //System.out.println("Cancel pressed");
                            }
                        } while (!isNumber || cancelled);

                        if (!cancelled) {
                            boolean valasz = proc.kolcsonzes(userID, jatek.getVonalkod(), napok);
                            if (valasz) {
                                Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Sikeres kölcsönzés.");
                                alert.setHeaderText("Siker");
                                alert.setTitle("Siker");
                                alert.showAndWait();
                                updateKolcsonzesek();
                            } else {
                                Alert alert = new Alert(Alert.AlertType.ERROR, "Sikertelen kölcsönzés.");
                                alert.setHeaderText("Hiba");
                                alert.setTitle("Hiba");
                                alert.showAndWait();
                            }
                        } else {
                            Alert alert = new Alert(Alert.AlertType.ERROR, "Kölcsönzés megszakítva.");
                            alert.setHeaderText("Hiba");
                            alert.setTitle("Hiba");
                            alert.showAndWait();
                        }
                    } else {
                        Alert alert = new Alert(Alert.AlertType.ERROR, splitted[0] + " tartozik így nem vehez ki új játékot.");
                        alert.setHeaderText("Hiba");
                        alert.setTitle("Hiba");
                        alert.showAndWait();
                    }
                }else{
                    Alert alert = new Alert(Alert.AlertType.ERROR,"A kölcsönző nem elég idős a játékhoz.");
                    alert.setHeaderText("Hiba");
                    alert.setTitle("Hiba");
                    alert.showAndWait();
                }
            }else{
                Alert alert = new Alert(Alert.AlertType.ERROR,"Nincs kölcsönző kiválasztva.");
                alert.setHeaderText("Hiba");
                alert.setTitle("Hiba");
                alert.showAndWait();
            }
        }else{
            Alert alert = new Alert(Alert.AlertType.ERROR,"Nincs játék kiválasztva.");
            alert.setHeaderText("Hiba");
            alert.setTitle("Hiba");
            alert.showAndWait();
        }

    }
    public static boolean isNumeric(String strNum) {
        try {
            int d = Integer.parseInt(strNum);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }

    @FXML
    protected void onVisszavisz(){

        int temp = kolcsonzesTable.getSelectionModel().getSelectedIndex();
        if(temp>=0){
            Rents kolcsonzes = kolcsonzesTable.getSelectionModel().getSelectedItem();
            int valasz = proc.visszaVitel(kolcsonzes.getKolcsonId());

            if(valasz ==1){
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION,"Sikeres visszavitel.");
                alert.setHeaderText("Siker");
                alert.setTitle("Siker");
                alert.showAndWait();
                updateKolcsonzesek();
            }else{
                Alert alert = new Alert(Alert.AlertType.ERROR,"Sikertelen visszavitel.");
                alert.setHeaderText("Hiba");
                alert.setTitle("Hiba");
                alert.showAndWait();
            }

        }else{
            Alert alert = new Alert(Alert.AlertType.ERROR,"Nincs kölcsönzés kiválasztva.");
            alert.setHeaderText("Hiba");
            alert.setTitle("Hiba");
            alert.showAndWait();
        }
    }
    @FXML
    protected void onKilepes(){
        connector.stopConnection();
        Stage stage = (Stage) mainCloseButton.getParentPopup().getOwnerWindow();
        stage.close();
    }

    @FXML
    protected void onUjJatek(){
        try{
            Stage jatekStage = new Stage();
            jatekStage.setTitle("Új Játek");
            FXMLLoader jatekLoader = new FXMLLoader(getClass().getResource("ujJatekWindow.fxml"));
            jatekLoader.setController(new ujJatekWindowController(proc));
            Pane ujJatekPane = jatekLoader.load();
            Scene kolcsonzoScene = new Scene(ujJatekPane);
            jatekStage.setScene(kolcsonzoScene);
            jatekStage.showAndWait();
            updateJatekok();

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @FXML
    protected void onUjKolcsonzo(){
        try{
            Stage kolcsonzoStage = new Stage();
            kolcsonzoStage.setTitle("Új Kölcsönző");
            FXMLLoader kolcsonzoLoader = new FXMLLoader(getClass().getResource("ujKolcsonzoWindow.fxml"));
            kolcsonzoLoader.setController(new ujKolcsonzoWindowController(proc));
            Pane ujKolcsonzoPane = kolcsonzoLoader.load();
            Scene kolcsonzoScene = new Scene(ujKolcsonzoPane);
            kolcsonzoStage.setScene(kolcsonzoScene);
            kolcsonzoStage.showAndWait();
            searchKolcsonzok();

        }catch (Exception e){
            e.printStackTrace();
        }

    }
    protected void onKolcsonzoTorles(){
        try{
            Stage kolcsTorlesStage = new Stage();
            kolcsTorlesStage.setTitle("Kolcsönző törlése");
            FXMLLoader kolcsTorlesLoader = new FXMLLoader(getClass().getResource("kolcsonzoTorles.fxml"));
            kolcsTorlesLoader.setController(new kolcsonzoTorlesWIndowController(proc));
            Pane kolcsTorlesPane = kolcsTorlesLoader.load();
            Scene kolcsTorlesScene = new Scene(kolcsTorlesPane);
            kolcsTorlesStage.setScene(kolcsTorlesScene);
            kolcsTorlesStage.showAndWait();
            searchKolcsonzok();

        }catch (Exception e){
            e.printStackTrace();
        }

    }

    protected void onJatekTorles(){
        try{
            Stage jatekTorlesStage = new Stage();
            jatekTorlesStage.setTitle("Kolcsönző törlése");
            FXMLLoader jatekTorlesLoader = new FXMLLoader(getClass().getResource("kolcsonzoTorles.fxml"));
            jatekTorlesLoader.setController(new jatekTorlesWindowController(proc));
            Pane kolcsTorlesPane = jatekTorlesLoader.load();
            Scene kolcsTorlesScene = new Scene(kolcsTorlesPane);
            jatekTorlesStage.setScene(kolcsTorlesScene);
            jatekTorlesStage.showAndWait();
            searchKolcsonzok();

        }catch (Exception e){
            e.printStackTrace();
        }

    }
    void updateJatekok(){
        col_jatek_nev.setCellValueFactory(new PropertyValueFactory<Jatekok,String>("nev"));
        col_jatek_kor.setCellValueFactory(new PropertyValueFactory<Jatekok,Integer>("korhatar"));
        col_jatek_platf.setCellValueFactory(new PropertyValueFactory<Jatekok,String>("Platform"));
        col_jatek_kat.setCellValueFactory(new PropertyValueFactory<Jatekok,String>("Kategoria"));
        col_jatek_eler.setCellValueFactory(new PropertyValueFactory<Jatekok,String>("Elerhetoseg"));
        jatekokList = proc.getJatekok();
        jatekokTable.setItems(jatekokList);
        SortedList<Jatekok> sortedData = new SortedList<>(jatekokList);
        sortedData.comparatorProperty().bind(jatekokTable.comparatorProperty());
        jatekokTable.setItems(sortedData);
    }

    void updateKolcsonzesek(){
        col_kolcson_jatek.setCellValueFactory(new PropertyValueFactory<Rents,String>("Jatek"));
        col_kolcson_kolcson.setCellValueFactory(new PropertyValueFactory<Rents,String>("Kolcsonzo"));
        col_kolcson_email.setCellValueFactory(new PropertyValueFactory<Rents,String>("Email"));
        col_kolcson_kolcs_datum.setCellValueFactory(new PropertyValueFactory<Rents,String>("Kolcs_datum"));
        col_kolcson_napok.setCellValueFactory(new PropertyValueFactory<Rents,String>("napok"));
        col_kolcson_lejart.setCellValueFactory(new PropertyValueFactory<Rents,String>("Lejart"));
        KolcsonzesekList = proc.getKolcsonzesek();
        kolcsonzesTable.setItems(KolcsonzesekList);
        SortedList<Rents> sortedData = new SortedList<>(KolcsonzesekList);
        sortedData.comparatorProperty().bind(kolcsonzesTable.comparatorProperty());
        kolcsonzesTable.setItems(sortedData);
    }

    void updateKolcsonzok(){
        KolcsonzoList = proc.getKolcsonzok();
        kolcsonzoComboBox.setItems(KolcsonzoList);
    }
    void searchJatekok() {
        col_jatek_nev.setCellValueFactory(new PropertyValueFactory<Jatekok,String>("nev"));
        col_jatek_kor.setCellValueFactory(new PropertyValueFactory<Jatekok,Integer>("korhatar"));
        col_jatek_platf.setCellValueFactory(new PropertyValueFactory<Jatekok,String>("Platform"));
        col_jatek_kat.setCellValueFactory(new PropertyValueFactory<Jatekok,String>("Kategoria"));
        col_jatek_eler.setCellValueFactory(new PropertyValueFactory<Jatekok,String>("Elerhetoseg"));
        jatekokList = proc.getJatekok();
        jatekokTable.setItems(jatekokList);


        FilteredList<Jatekok> jatekokFilter =new FilteredList<>(jatekokList, b -> true);

        searchJatekInput.textProperty().addListener((observable, oldvalue, newvalue) -> {
            jatekokFilter.setPredicate(Jatekok -> {

                if (newvalue.isEmpty() || newvalue.isBlank() || newvalue == null){
                    return true;
                }
                String searchKeyWord = newvalue.toLowerCase();

                if(Jatekok.getPlatform().toLowerCase().contains(searchKeyWord)){
                    return true;
                }else if(Jatekok.getNev().toLowerCase().contains(searchKeyWord)){
                    return true;
                }else if(Jatekok.getKategoria().toLowerCase().contains(searchKeyWord)){
                    return true;
                }else if(Jatekok.getElerhetoseg().toLowerCase().contains(searchKeyWord)){
                    return true;
                }else{
                    return false;
                }

            });
        });

        SortedList<Jatekok> jatekokSorted = new SortedList<>(jatekokFilter);
        jatekokSorted.comparatorProperty().bind(jatekokTable.comparatorProperty());
        jatekokTable.setItems(jatekokSorted);



    }

    void searchKolcsonzok() {
        KolcsonzoList = proc.getKolcsonzok();
        kolcsonzoComboBox.setItems(KolcsonzoList);
        //
    }

    void searchKolcsonzesek() {
        col_kolcson_jatek.setCellValueFactory(new PropertyValueFactory<Rents,String>("Jatek"));
        col_kolcson_kolcson.setCellValueFactory(new PropertyValueFactory<Rents,String>("Kolcsonzo"));
        col_kolcson_email.setCellValueFactory(new PropertyValueFactory<Rents,String>("Email"));
        col_kolcson_kolcs_datum.setCellValueFactory(new PropertyValueFactory<Rents,String>("Kolcs_datum"));
        col_kolcson_napok.setCellValueFactory(new PropertyValueFactory<Rents,String>("napok"));
        col_kolcson_lejart.setCellValueFactory(new PropertyValueFactory<Rents,String>("Lejart"));
        KolcsonzesekList = proc.getKolcsonzesek();
        kolcsonzesTable.setItems(KolcsonzesekList);


        FilteredList<Rents> rentsFilter =new FilteredList<>(KolcsonzesekList, b -> true);

        searchKolcsonzesInput.textProperty().addListener((observable, oldvalue, newvalue) -> {
            rentsFilter.setPredicate(Rents -> {

                if (newvalue.isEmpty() || newvalue.isBlank() || newvalue==null){
                    return true;
                }
                String searchKeyWord = newvalue.toLowerCase();
                System.out.println(searchKeyWord);

                if(Rents.getJatek().toLowerCase().contains(searchKeyWord)){
                    return true;
                }else if(Rents.getKolcsonzo().toLowerCase().contains(searchKeyWord)){
                    return true;
                }else if(Rents.getEmail().toLowerCase().contains(searchKeyWord)){
                    return true;
                }else if(Rents.getKolcs_datum().toLowerCase().contains(searchKeyWord)){
                    return true;
                }else{
                    return false;
                }

            });
        });

        SortedList<Rents> sortedData = new SortedList<>(rentsFilter);
        sortedData.comparatorProperty().bind(kolcsonzesTable.comparatorProperty());
        kolcsonzesTable.setItems(sortedData);
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        proc = new Process(connector);
        proc.searchTartozasok();
        searchJatekInput.setPromptText("Keresés");
        searchKolcsonzesInput.setPromptText("Keresés");
        searchKolcsonzesek();
        searchJatekok();
        searchKolcsonzok();
    }

}