package com.example.kolcsonzo;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import com.example.kolcsonzo.Classes.Process;
import javafx.stage.Stage;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class ujKolcsonzoWindowController {
    @FXML
    public DatePicker szulDatePicker;
    @FXML
    public TextField nevTextField;
    @FXML
    public TextField emailTextField;
    public Button closeButton;
    Process proc;

    public ujKolcsonzoWindowController(Process process){
        proc = process;
    }


    @FXML
    protected void onHozzaad(){
        if ((nevTextField.getText() == null || nevTextField.getText().trim().isEmpty()) || (emailTextField.getText() == null || emailTextField.getText().trim().isEmpty())) {
            if(nevTextField.getText() == null || nevTextField.getText().trim().isEmpty()){
                nevTextField.setStyle("-fx-text-box-border: red");
            }else{
                nevTextField.setStyle("-fx-text-box-border: black");
            }

            if(emailTextField.getText() == null || emailTextField.getText().trim().isEmpty()){
                emailTextField.setStyle("-fx-text-box-border: red");
            }else{
                emailTextField.setStyle("-fx-text-box-border: black");
            }
            Alert alert = new Alert(Alert.AlertType.ERROR,"Nincs kitöltve a név és/vagy Email cím.");
            alert.setHeaderText("Hiba");
            alert.setTitle("Hiba");
            alert.showAndWait();
        }else{
            if(isValidEmail(emailTextField.getText())) {
                if (szulDatePicker.getValue() != null) {
                    LocalDate szulDate = szulDatePicker.getValue();
                    if(proc.countVevo(emailTextField.getText())){
                        proc.setVevo(nevTextField.getText(), emailTextField.getText(), szulDate);
                        Alert alert = new Alert(Alert.AlertType.INFORMATION,"Sikeresen hozzá lett adva az új kölcönző.");
                        alert.setHeaderText("Siker");
                        alert.setTitle("Siker");
                        alert.showAndWait();
                        onMegse();
                    }else{
                        Alert alert = new Alert(Alert.AlertType.ERROR, "A felhasználó a(z) "+ emailTextField.getText()+" email címmel má regisztrála van.");
                        alert.setHeaderText("Hiba");
                        alert.setTitle("Hiba");
                        alert.showAndWait();
                    }
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR, "Nincs születési dátum kiválasztva.");
                    alert.setHeaderText("Hiba");
                    alert.setTitle("Hiba");
                    alert.showAndWait();
                }
            }else{
                Alert alert = new Alert(Alert.AlertType.ERROR, "Nem való email cím.");
                alert.setHeaderText("Hiba");
                alert.setTitle("Hiba");
                alert.showAndWait();
            }

        }
    }
    @FXML
    protected void onMegse(){
        Stage stage = (Stage) closeButton.getScene().getWindow();
        stage.close();
    }

    private boolean isValidEmail(String mail){
        String regex = "^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^-]+(?:\\.[a-zA-Z0-9_!#$%&'*+/=?`{|}~^-]+)*@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*\\.[a-zA-Z]{2,}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(mail);

        return matcher.matches();
    }
}
