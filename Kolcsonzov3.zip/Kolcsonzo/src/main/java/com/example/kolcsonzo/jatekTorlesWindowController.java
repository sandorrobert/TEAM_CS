package com.example.kolcsonzo;

import com.example.kolcsonzo.Classes.Process;

public class jatekTorlesWindowController {

    Process proc;
    public jatekTorlesWindowController(Process pr){
        proc = pr;
    }
}
