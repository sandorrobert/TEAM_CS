package com.example.kolcsonzo;

import com.example.kolcsonzo.Classes.Process;

public class kolcsonzoTorlesWIndowController {
    Process proc;
    public kolcsonzoTorlesWIndowController(Process pr){
        proc = pr;
    }
}
