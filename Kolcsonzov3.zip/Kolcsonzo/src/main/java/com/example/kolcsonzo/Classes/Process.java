package com.example.kolcsonzo.Classes;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Date;

public class Process {

    Connector con;

    public Process(Connector conn){
        con = conn;
    }

    public ObservableList<Jatekok> getJatekok(){
        ObservableList<Jatekok> list = FXCollections.observableArrayList();
        try {
            ResultSet rs = con.getInfoFromDatabase("SELECT * FROM jatekok;");


            while (rs.next()){
                list.add(new Jatekok(Integer.parseInt(rs.getString("Vonalkod_ID")), rs.getString("Nev"), rs.getInt("Eletkor"), rs.getString("Platform"), rs.getString("Kategoria"), rs.getBoolean("Elerhetoseg")));
            }
        } catch (Exception e) {
        }
        return list;
    }


    public ObservableList<Rents> getKolcsonzesek(){
        ObservableList<Rents> list = FXCollections.observableArrayList();
        try {
            ResultSet rs = con.getInfoFromDatabase("SELECT k.Kolcsonzes_ID, j.Nev, v.Nev, v.Email_cim, k.Kolcsonzes_datuma, k.Kolcsonzott_napok, k.Lejart FROM vevok v, kikolcsonzott_jatekok k, jatekok j WHERE v.Vevo_ID=k.Felhasznalo_ID AND j.Vonalkod_ID=k.Jatek_ID AND k.Visszahozas_datuma IS NULL;");


            while (rs.next()){
                list.add(new Rents(Integer.parseInt(rs.getString("k.Kolcsonzes_ID")),
                                                    rs.getString("j.Nev"),
                                                    rs.getString("v.Nev"),
                                                    rs.getString("v.Email_cim"),
                                                    rs.getString("k.Kolcsonzes_datuma"),
                                                    rs.getInt("k.Kolcsonzott_napok"),
                                                    rs.getBoolean("k.Lejart")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public ObservableList getKolcsonzok(){
        ObservableList list = FXCollections.observableArrayList();
        try {
            ResultSet rs = con.getInfoFromDatabase("SELECT * FROM vevok;");


            while (rs.next()){
                list.add(new Users(Integer.parseInt(rs.getString("Vevo_ID")),
                                                    rs.getString("Nev"),
                                                    rs.getString("Email_cim"),
                                                    rs.getString("Szuletes_datum")).getEmail_nev()); //átírni dátumra és vizsgálni , hogy korhatárba belefér-e a user a kölcsönzésnél
            }
        } catch (Exception e) {
        }
        return list;
    }

    public boolean isOldEnough(int korhatar, String useremail){
        boolean valasz = false;
        try{
            ResultSet rs = con.getInfoFromDatabase("SELECT Szuletes_datum FROM vevok WHERE Email_cim='"+useremail+"';" );
            rs.next();
            String userKor = rs.getString(1);
            String[] splitted = userKor.split("-");
            LocalDate today = LocalDate.now();
            LocalDate birthday = LocalDate.of(Integer.parseInt(splitted[0]), Integer.parseInt(splitted[1]), Integer.parseInt(splitted[2]));
            int vevoKor = Period.between(birthday, today).getYears();
            if(vevoKor >= korhatar){
                valasz = true;
            }
        }catch (Exception e){
            return false;
        }
        return valasz;
    }

    public void searchTartozasok(){
        String sql = "SELECT k.Kolcsonzes_ID, v.Vevo_ID, k.Kolcsonzes_datuma, k.Kolcsonzott_napok FROM vevok v, kikolcsonzott_jatekok k WHERE v.Vevo_ID=k.Felhasznalo_ID AND k.Visszahozas_datuma IS NULL;";
        try {

            ResultSet rs = con.getInfoFromDatabase(sql);
            while(rs.next()) {
                int kolcsID = rs.getInt(1);
                int userID = rs.getInt(2);
                String kolcsDatum = rs.getString(3);
                int napok = rs.getInt(4);

                Date date = new Date();
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
                LocalDate kolcsDate = LocalDate.parse(kolcsDatum);
                LocalDate currDate = LocalDate.parse(formatter.format(date));
                kolcsDate = kolcsDate.plusDays(napok);
                if (kolcsDate.isBefore(currDate)) {
                    setTartozas(userID, kolcsID);
                }
            }
        }catch (Exception e){
        }
    }
    public void setTartozas(int userID, int kolcsonID){
        String sql = "UPDATE vevok SET Tartozas = 1 WHERE Vevo_ID="+userID+";";
        String sql2 = "UPDATE kikolcsonzott_jatekok SET Lejart = 1 WHERE Kolcsonzes_ID="+kolcsonID+";";
        con.setInfoToDatabase(sql);
        con.setInfoToDatabase(sql2);
    }
    public void setVevo(String felhaszn, String email, LocalDate kor){
        try {
            String sql = "INSERT INTO vevok (Nev, Szuletes_datum, Email_cim, Tartozas) VALUES ('" + felhaszn + "','" + kor + "','" + email + "',0) ;";
            System.out.println(sql);
            int valasz = con.setInfoToDatabase(sql);
        }catch (Exception e){
            System.out.println(e);
        }
    }
    public boolean countVevo(String vevoEmail){
        boolean isNotRegistered = false;
        try{
            String query = "SELECT COUNT(*) FROM vevok WHERE Email_cim='"+vevoEmail+"';";
            ResultSet result  = con.getInfoFromDatabase(query);
            result.next();
            int count = result.getInt(1);
            if (count <1){
                isNotRegistered = true;
            }
        }catch (SQLException e){
        }

        return isNotRegistered;
    }

    public int[] setJatek(String jatekNev, int ar, String kiado, String kategoria, String platform, int minKor){
        int[] valasz={0, 0};
        String sql = "INSERT INTO jatekok (Nev, Ar, Kiado, Kategoria, Platform, Eletkor, Elerhetoseg) VALUES ('"+jatekNev+"',"+ar+",'"+kiado+"','"+kategoria+"','"+platform+"',"+minKor+",1);";
        String query ="SELECT Vonalkod_ID FROM jatekok WHERE Nev='"+jatekNev+"';";
        con.setInfoToDatabase(sql);
        try{
            ResultSet rs = con.getInfoFromDatabase(query);
            rs.next();
            valasz[1] = rs.getInt(1);
        }catch (Exception e){
            valasz[0]=99;
            return valasz;
        }
        valasz[0]=40;
        return valasz;
    }

    public boolean searchJatek(String jatekNev){
        boolean isNotRegistered = false;
        int count = 0;
        try{
            String query = "SELECT COUNT(*) FROM jatekok WHERE Nev='"+jatekNev+"';";
            ResultSet result  = con.getInfoFromDatabase(query);
            result.next();

            count = result.getInt(1);
            if (count <1){
                isNotRegistered = true;
            }
        }catch (SQLException e){
        }

        return isNotRegistered;
    }

    public boolean searchTartozas(String vevoEmail){
        boolean tartozik = false;
        try{
            String query = "SELECT Tartozas FROM vevok WHERE Email_cim='"+vevoEmail+"';";
            ResultSet result = con.getInfoFromDatabase(query);
            result.next();
            String tmp = result.getString(1);
            if(tmp.equals("1")){
                tartozik = true;
            }else{
                tartozik=false;
            }

        }catch (SQLException e){
        }

        return tartozik;
    }
    public int searchUserID(String vevoEmail){
        int userid = -1;
        try{
            String query = "SELECT Vevo_ID FROM vevok WHERE Email_cim='"+vevoEmail+"';";
            ResultSet result =  con.getInfoFromDatabase(query);

            result.next();
            userid = result.getInt(1);

        }catch (SQLException e){
        }

        return userid;
    }
    public boolean kolcsonzes(int UserID, int GameID, int napok) {
        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String sql = "INSERT INTO kikolcsonzott_jatekok (Felhasznalo_ID, Jatek_ID, Kolcsonzes_datuma, Kolcsonzott_napok, Lejart) VALUES ("+UserID+","+GameID+",'"+formatter.format(date)+"',"+napok+",0);";
        boolean valasz = false;
        try {
            con.setInfoToDatabase(sql);

        } catch (Exception e) {
            return valasz;
        }
        valasz = true;
        return valasz;
    }
    public int visszaVitel(int KolcsonzesID) {

        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

        String sql ="SELECT Felhasznalo_ID FROM kikolcsonzott_jatekok WHERE Kolcsonzes_ID='"+KolcsonzesID+"';";

        String query1 = "UPDATE kikolcsonzott_jatekok SET Lejart = 0 , Visszahozas_datuma='"+formatter.format(date)+"' WHERE Kolcsonzes_ID="+KolcsonzesID+";";
        int valasz = 0;
        int VevoID;
        try {
            ResultSet result =  con.getInfoFromDatabase(sql);

            result.next();
            VevoID = result.getInt(1);

            valasz = con.setInfoToDatabase(query1);

            String sql2 = "SELECT COUNT(*) FROM kikolcsonzott_jatekok WHERE Felhasznalo_ID="+VevoID+" AND Lejart=1;";
            ResultSet result2 = con.getInfoFromDatabase(sql2);
            result2.next();
            int tartozike = result2.getInt(1);
            if(tartozike>0) {
                String query2 = "UPDATE vevok SET Tartozas = 1 WHERE Vevo_ID=" + VevoID + ";";
                valasz = con.setInfoToDatabase(query2);
            }else {
                String query2 = "UPDATE vevok SET Tartozas = 0 WHERE Vevo_ID="+VevoID+";";
                valasz = con.setInfoToDatabase(query2);
            }


        } catch (Exception e) {
            return 91;
        }
        return valasz;
    }
}
