module com.example.kolcsonzo {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires org.kordamp.ikonli.javafx;
    requires org.kordamp.bootstrapfx.core;
    requires java.sql;

    opens com.example.kolcsonzo to javafx.fxml;
    exports com.example.kolcsonzo;

    exports com.example.kolcsonzo.Classes;
}