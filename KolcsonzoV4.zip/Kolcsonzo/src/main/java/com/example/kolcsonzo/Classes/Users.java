package com.example.kolcsonzo.Classes;

public class Users {
// ez pedig a kölcsönzöket példányosítja
    int Vevo_ID;
    String Vevo_Nev, Vevo_email, email_nev, Vevo_Szuletesi_Datum, Aktiv;

    public Users(int id, String nev, String mail, String szul_datum, boolean aktiv){
        Vevo_ID = id;
        Vevo_Nev = nev;
        Vevo_email = mail;
        Vevo_Szuletesi_Datum = szul_datum;
        email_nev = nev+";"+mail;
        if(aktiv){
            Aktiv = "Aktív";
        }else{
            Aktiv = "Nem aktív";
        }

    }

    public int getVevo_ID() {
        return Vevo_ID;
    }

    public String getVevo_Szuletesi_Datum() {
        return Vevo_Szuletesi_Datum;
    }

    public String getEmail_nev() {
        return email_nev;
    }

    public String getVevo_email() {
        return Vevo_email;
    }

    public String getVevo_Nev() {
        return Vevo_Nev;
    }

    public String getAktiv() {
        return Aktiv;
    }
}
