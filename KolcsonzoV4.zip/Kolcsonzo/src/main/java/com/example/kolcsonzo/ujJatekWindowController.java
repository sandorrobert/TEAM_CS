package com.example.kolcsonzo;

import com.example.kolcsonzo.Classes.Process;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.stage.Stage;
import javafx.util.StringConverter;
import javafx.util.converter.IntegerStringConverter;

import java.time.LocalDate;
import java.util.function.UnaryOperator;

// Itt kapcsoljuk össze a GUI-t magával a programmal, a müködési logikával. fxml mappák

public class ujJatekWindowController {

    @FXML
    public TextField jatekNev;
    @FXML
    public TextField jatekKiado;
    @FXML
    public TextField jatekPlatform;
    @FXML
    public TextField jatekKorhatar;
    @FXML
    public TextField jatekAr;
    @FXML
    public TextField jatekKategoria;
    @FXML
    public Button closeJatekButton;
    Process proc;

    public ujJatekWindowController(Process process){
        proc = process;
    }

    @FXML
    protected void onJatekHozzaad(){
        if((jatekNev.getText() == null || jatekNev.getText().trim().isEmpty()) ||
           (jatekKiado.getText() == null || jatekKiado.getText().trim().isEmpty()) ||
           (jatekPlatform.getText() == null || jatekPlatform.getText().trim().isEmpty()) ||
           (jatekKorhatar.getText() == null || jatekKorhatar.getText().trim().isEmpty()) ||
           (jatekAr.getText() == null || jatekAr.getText().trim().isEmpty()) ||
           (jatekKategoria.getText() == null || jatekKategoria.getText().trim().isEmpty())) {
            if(jatekNev.getText() == null || jatekNev.getText().trim().isEmpty()){
                jatekNev.setStyle("-fx-text-box-border: red");
            }else{
                jatekNev.setStyle("-fx-text-box-border: grey");
            }
            if(jatekKiado.getText() == null || jatekKiado.getText().trim().isEmpty()){
                jatekKiado.setStyle("-fx-text-box-border: red");
            }else{
                jatekKiado.setStyle("-fx-text-box-border: grey");
            }
            if(jatekPlatform.getText() == null || jatekPlatform.getText().trim().isEmpty()){
                jatekPlatform.setStyle("-fx-text-box-border: red");
            }else{
                jatekPlatform.setStyle("-fx-text-box-border: grey");
            }
            if(jatekKorhatar.getText() == null || jatekKorhatar.getText().trim().isEmpty()){
                jatekKorhatar.setStyle("-fx-text-box-border: red");
            }else{
                jatekKorhatar.setStyle("-fx-text-box-border: grey");
            }
            if(jatekAr.getText() == null || jatekAr.getText().trim().isEmpty()){
                jatekAr.setStyle("-fx-text-box-border: red");
            }else{
                jatekAr.setStyle("-fx-text-box-border: grey");
            }
            if(jatekKategoria.getText() == null || jatekKategoria.getText().trim().isEmpty()){
                jatekKategoria.setStyle("-fx-text-box-border: red");
            }else{
                jatekKategoria.setStyle("-fx-text-box-border: grey");
            }
            Alert alert = new Alert(Alert.AlertType.ERROR,"Egy vagy több mező nincskitöltve.");
            alert.setHeaderText("Hiba");
            alert.setTitle("Hiba");
            alert.showAndWait();
        }else{
            if(isNumeric(jatekAr.getText()) && isNumeric(jatekKorhatar.getText())){
                if(proc.searchJatek(jatekNev.getText())){
                    jatekNev.setStyle("-fx-text-box-border: grey");
                    jatekKiado.setStyle("-fx-text-box-border: grey");
                    jatekPlatform.setStyle("-fx-text-box-border: grey");
                    jatekKorhatar.setStyle("-fx-text-box-border: grey");
                    jatekAr.setStyle("-fx-text-box-border: grey");
                    jatekKategoria.setStyle("-fx-text-box-border: grey");
                    proc.setJatek(jatekNev.getText(),
                            Integer.parseInt(jatekAr.getText()),
                            jatekKiado.getText(),
                            jatekKategoria.getText(),
                            jatekPlatform.getText(),
                            Integer.parseInt(jatekKorhatar.getText()));
                    Alert alert = new Alert(Alert.AlertType.INFORMATION,"Sikeresen hozzá lett adva a játék.");
                    alert.setHeaderText("Siker");
                    alert.setTitle("Siker");
                    alert.showAndWait();
                    onJatekMegse();
                }else{
                    Alert alert = new Alert(Alert.AlertType.ERROR,"A játék már létezik az adatbázisban.");
                    alert.setHeaderText("Hiba");
                    alert.setTitle("Hiba");
                    alert.showAndWait();
                }
            }else{
                if(!isNumeric(jatekAr.getText())){
                    jatekAr.setStyle("-fx-text-box-border: red");
                    Alert alert = new Alert(Alert.AlertType.ERROR,"Az Ár mező nem szám.");
                    alert.setHeaderText("Hiba");
                    alert.setTitle("Hiba");
                    alert.showAndWait();
                }else{
                    jatekAr.setStyle("-fx-text-box-border: grey");
                }
                if(!isNumeric(jatekKorhatar.getText())){
                    jatekKorhatar.setStyle("-fx-text-box-border: red");
                    Alert alert = new Alert(Alert.AlertType.ERROR,"A Korhatár mező nem szám.");
                    alert.setHeaderText("Hiba");
                    alert.setTitle("Hiba");
                    alert.showAndWait();
                }else{
                    jatekKorhatar.setStyle("-fx-text-box-border: grey");
                }
            }
        }
    }
    @FXML
    protected void onJatekMegse(){
        Stage stage = (Stage) closeJatekButton.getScene().getWindow();
        stage.close();
    }

    public static boolean isNumeric(String str) {
        try {
            Integer.parseInt(str);
            return true;
        } catch(NumberFormatException e){
            return false;
        }
    }
}
