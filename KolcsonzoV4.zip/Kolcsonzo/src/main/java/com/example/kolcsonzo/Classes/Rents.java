package com.example.kolcsonzo.Classes;

public class Rents {
// innen fogja a kölcsönzéseket példányosítani
    int KolcsonId, napok;
    String Jatek, Kolcsonzo, Email, Lejart, Kolcs_datum;

    public Rents(int id, String JatekNev, String Kolcson_nev, String Kolcson_Email, String Kocson_datum, int nap, boolean lejarat){
        KolcsonId = id;
        Jatek = JatekNev;
        Kolcsonzo = Kolcson_nev;
        Email = Kolcson_Email;
        Kolcs_datum = Kocson_datum;
        napok = nap;
        if(lejarat){
            Lejart = "Lejárt";
        }else{
            Lejart="Nem járt le";
        }
    }

    public String getEmail() {
        return Email;
    }

    public int getKolcsonId() {
        return KolcsonId;
    }

    public int getNapok() {
        return napok;
    }

    public String getJatek() {
        return Jatek;
    }

    public String getKolcs_datum() {
        return Kolcs_datum;
    }

    public String getKolcsonzo() {
        return Kolcsonzo;
    }

    public String getLejart() {
        return Lejart;
    }
}
