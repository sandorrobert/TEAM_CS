package com.example.kolcsonzo;

import com.example.kolcsonzo.Classes.Connector;
import com.example.kolcsonzo.Classes.Jatekok;
import com.example.kolcsonzo.Classes.Process;
import com.example.kolcsonzo.Classes.Users;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class jatekTorlesWindowController implements Initializable {
// Itt kapcsoljuk össze a GUI-t magával a programmal, a müködési logikával. fxml mappák
    Connector connector = new Connector("konzolbolt", "root", "", "localhost");
    public TableView<Jatekok> jatekTorlesTable;
    public TableColumn<Jatekok, String> colJatekTorlesNev;
    public TableColumn<Jatekok, String>  colJatekElerheto;
    public TextField searchJatekTorlesInput = new TextField();

    public Button jatekElerhetoButton;
    ObservableList<Jatekok> jatekokTorlesList;
    Process proc;
    void onSearchJatekTorles(){
        jatekokTorlesList = proc.getAllJatekok();
        colJatekTorlesNev.setCellValueFactory(new PropertyValueFactory<Jatekok,String>("nev"));
        colJatekElerheto.setCellValueFactory(new PropertyValueFactory<Jatekok,String>("Elerhetoseg"));
        jatekTorlesTable.setItems(jatekokTorlesList);

        FilteredList<Jatekok> jatekokFilter =new FilteredList<>(jatekokTorlesList, b -> true);

        searchJatekTorlesInput.textProperty().addListener((observable, oldvalue, newvalue) -> {
            jatekokFilter.setPredicate(Jatekok -> {

                if (newvalue.isEmpty() || newvalue.isBlank() || newvalue == null){
                    return true;
                }
                String searchKeyWord = newvalue.toLowerCase();

                if(Jatekok.getPlatform().toLowerCase().contains(searchKeyWord)){
                    return true;
                }else if(Jatekok.getNev().toLowerCase().contains(searchKeyWord)){
                    return true;
                }else if(Jatekok.getKategoria().toLowerCase().contains(searchKeyWord)){
                    return true;
                }else if(Jatekok.getElerhetoseg().toLowerCase().contains(searchKeyWord)){
                    return true;
                }else{
                    return false;
                }

            });
        });

        SortedList<Jatekok> jatekokSorted = new SortedList<>(jatekokFilter);
        jatekokSorted.comparatorProperty().bind(jatekTorlesTable.comparatorProperty());
        jatekTorlesTable.setItems(jatekokSorted);
    }

    public void onElerhetoseg(){
        int temp = jatekTorlesTable.getSelectionModel().getSelectedIndex();
        if(temp>=0){
            Jatekok jatek = jatekTorlesTable.getSelectionModel().getSelectedItem();
            if(jatek.getElerhetoseg().equals("Elérhető")){
                int valasz = proc.jatekNemElerheto(jatek.getVonalkod());
                if(valasz ==1){
                    ButtonType yesButtonType = new ButtonType("Igen", ButtonBar.ButtonData.OK_DONE);
                    ButtonType noButtonType = new ButtonType("Nem", ButtonBar.ButtonData.CANCEL_CLOSE);
                    Alert alert = new Alert(Alert.AlertType.INFORMATION,
                            jatek.getNev()+" mostmár nem elérhető. \n Kíván más játékot is deaktiválni?",
                            yesButtonType,
                            noButtonType);

                    alert.setHeaderText("Siker");
                    alert.setTitle("Siker");
                    Optional<ButtonType> result = alert.showAndWait();
                    if (result.orElse(yesButtonType) == noButtonType) {
                        onKilepes();
                    }else{
                        onSearchJatekTorles();
                    }
                }else{
                    Alert alert = new Alert(Alert.AlertType.ERROR,"Hiba a folyamatban.");
                    alert.setHeaderText("Hiba");
                    alert.setTitle("Hiba");
                    alert.showAndWait();
                }
            }else{
                int valasz = proc.jatekElerheto(jatek.getVonalkod());
                if(valasz ==1){
                    ButtonType yesButtonType = new ButtonType("Igen", ButtonBar.ButtonData.OK_DONE);
                    ButtonType noButtonType = new ButtonType("Nem", ButtonBar.ButtonData.CANCEL_CLOSE);
                    Alert alert = new Alert(Alert.AlertType.INFORMATION,
                            jatek.getNev()+" mostmár elérhető. \n Kíván más játékot is elérhetővé tenni?",
                            yesButtonType,
                            noButtonType);
                    alert.setHeaderText("Siker");
                    alert.setTitle("Siker");
                    Optional<ButtonType> result = alert.showAndWait();
                    if (result.orElse(yesButtonType) == noButtonType) {
                        onKilepes();
                    }else{
                        onSearchJatekTorles();
                    }
                }else{
                    Alert alert = new Alert(Alert.AlertType.ERROR,"Hiba a folyamatban.");
                    alert.setHeaderText("Hiba");
                    alert.setTitle("Hiba");
                    alert.showAndWait();
                }
            }
        }else{
            Alert alert = new Alert(Alert.AlertType.ERROR,"Nincs játék kiválasztva.");
            alert.setHeaderText("Hiba");
            alert.setTitle("Hiba");
            alert.showAndWait();
        }
    }

    protected void onKilepes(){
        connector.stopConnection();
        Stage stage = (Stage) jatekElerhetoButton.getScene().getWindow();
        stage.close();
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        proc = new Process(connector);
        onSearchJatekTorles();

    }
}
