package com.example.kolcsonzo.Classes;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Date;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Process {

    private static final Logger logger = LogManager.getLogger(Process.class);

    Connector con;

    public Process(Connector conn){
        con = conn;
    }

// itt vannak az elérhető játékok a fő táblához
    public ObservableList<Jatekok> getJatekok(){
        ObservableList<Jatekok> list = FXCollections.observableArrayList();
        try {
            ResultSet rs = con.getInfoFromDatabase("SELECT * FROM jatekok WHERE Elerhetoseg=1;");


            while (rs.next()){
                list.add(new Jatekok(Integer.parseInt(rs.getString("Vonalkod_ID")), rs.getString("Nev"), rs.getInt("Eletkor"), rs.getString("Platform"), rs.getString("Kategoria"), rs.getBoolean("Elerhetoseg")));
            }
        } catch (Exception e) {
            logger.error("Error in Process.getJatekok \n "+e.getMessage());
        }
        return list;
    }
    // az össze game lekérése
    public ObservableList<Jatekok> getAllJatekok(){
        ObservableList<Jatekok> list = FXCollections.observableArrayList();
        try {
            ResultSet rs = con.getInfoFromDatabase("SELECT * FROM jatekok;");


            while (rs.next()){
                list.add(new Jatekok(Integer.parseInt(rs.getString("Vonalkod_ID")), rs.getString("Nev"), rs.getInt("Eletkor"), rs.getString("Platform"), rs.getString("Kategoria"), rs.getBoolean("Elerhetoseg")));
            }
        } catch (Exception e) {
            logger.error("Error in Process.getAllJatekok \n "+e.getMessage());
        }
        return list;
    }

// kölcsönzések lekérése
    public ObservableList<Rents> getKolcsonzesek(){
        ObservableList<Rents> list = FXCollections.observableArrayList();
        try {
            ResultSet rs = con.getInfoFromDatabase("SELECT k.Kolcsonzes_ID, j.Nev, v.Nev, v.Email_cim, k.Kolcsonzes_datuma, k.Kolcsonzott_napok, k.Lejart FROM vevok v, kikolcsonzott_jatekok k, jatekok j WHERE v.Vevo_ID=k.Felhasznalo_ID AND j.Vonalkod_ID=k.Jatek_ID AND k.Visszahozas_datuma IS NULL;");


            while (rs.next()){
                list.add(new Rents(Integer.parseInt(rs.getString("k.Kolcsonzes_ID")),
                                                    rs.getString("j.Nev"),
                                                    rs.getString("v.Nev"),
                                                    rs.getString("v.Email_cim"),
                                                    rs.getString("k.Kolcsonzes_datuma"),
                                                    rs.getInt("k.Kolcsonzott_napok"),
                                                    rs.getBoolean("k.Lejart")));
            }
        } catch (Exception e) {
            logger.error("Error in Process.getKolcsonzesek \n "+e.getMessage());
        }
        return list;
    }

    // Az aktív kölcsönzök lekérése
    public ObservableList getKolcsonzok(){
        ObservableList list = FXCollections.observableArrayList();
        try {
            ResultSet rs = con.getInfoFromDatabase("SELECT * FROM vevok WHERE Aktiv=1;");


            while (rs.next()){
                list.add(new Users(Integer.parseInt(rs.getString("Vevo_ID")),
                                                    rs.getString("Nev"),
                                                    rs.getString("Email_cim"),
                                                    rs.getString("Szuletes_datum"),
                                                    rs.getBoolean("Aktiv")).getEmail_nev()); //átírni dátumra és vizsgálni , hogy korhatárba belefér-e a user a kölcsönzésnél
            }
        } catch (Exception e) {
            logger.error("Error in Process.getKolcsonzok \n "+e.getMessage());
        }
        return list;
    }
// Az össze köcsönző lekérése
    public ObservableList<Users> getAllUsers(){
        ObservableList<Users> list = FXCollections.observableArrayList();
        try {
            ResultSet rs = con.getInfoFromDatabase("SELECT * FROM vevok;");


            while (rs.next()){
                list.add(new Users(Integer.parseInt(rs.getString("Vevo_ID")),
                        rs.getString("Nev"),
                        rs.getString("Email_cim"),
                        rs.getString("Szuletes_datum"),
                        rs.getBoolean("Aktiv")));
            }
        } catch (Exception e) {
            logger.error("Error in Process.getAllUsers \n "+e.getMessage());
        }
        return list;
    }
// Elég idős-e kozzá hogy kikérheti-e a game-et
    public boolean isOldEnough(int korhatar, String useremail){
        boolean valasz = false;
        try{
            ResultSet rs = con.getInfoFromDatabase("SELECT Szuletes_datum FROM vevok WHERE Email_cim='"+useremail+"';" );
            rs.next();
            String userKor = rs.getString(1);
            String[] splitted = userKor.split("-");
            LocalDate today = LocalDate.now();
            LocalDate birthday = LocalDate.of(Integer.parseInt(splitted[0]), Integer.parseInt(splitted[1]), Integer.parseInt(splitted[2]));
            int vevoKor = Period.between(birthday, today).getYears();
            if(vevoKor >= korhatar){
                valasz = true;
            }
        }catch (Exception e){
            logger.error("Error in Process.isOldEnough \n "+e.getMessage());
            return false;
        }
        return valasz;
    }
// deaktiválja a kölcsönzőket (csak akkor tudsz deaktiválni ha nincs aktiv kölcsönzése)
    public int kolcsonzoDeaktivalas(int userID){
        String countUSerRents = "SELECT COUNT(*) FROM kikolcsonzott_jatekok WHERE Felhasznalo_ID="+userID+" AND Visszahozas_datuma IS NULL;";
        try{
            ResultSet result  = con.getInfoFromDatabase(countUSerRents);
            result.next();
            int count = result.getInt(1);
            if (count <1){
                String userDelete = "UPDATE vevok SET Aktiv = 0 WHERE Vevo_ID="+userID+";";
                return con.setInfoToDatabase(userDelete);
            }
        }catch (Exception e){
            logger.error("Error in Process.kolcsonzoDeaktivalas \n "+e.getMessage());
            return 9;
        }
        return 8;
    }
// Itt meg Aktiválja a kölcsönzőt
    public int kolcsonzoAktivalas(int userID){
        try{
            String userDelete = "UPDATE vevok SET Aktiv = 1 WHERE Vevo_ID="+userID+";";
            return con.setInfoToDatabase(userDelete);
        }catch (Exception e){
            logger.error("Error in Process.kolcsonzoAktivalas \n "+e.getMessage());
            return 9;
        }
    }
// Megnézi hogy elérhető-e a game
    public int jatekElerheto(int jatekID){
        try{
            String userDelete = "UPDATE jatekok SET Elerhetoseg = 1 WHERE Vonalkod_ID="+jatekID+";";
            return con.setInfoToDatabase(userDelete);
        }catch (Exception e){
            logger.error("Error in Process.jatekElerheto \n "+e.getMessage());
            return 9;
        }
    }
// Itt meg megnézi hogy nem elérhető
    public int jatekNemElerheto(int jatekID){
        try{
            String userDelete = "UPDATE jatekok SET Elerhetoseg = 0 WHERE Vonalkod_ID="+jatekID+";";
            return con.setInfoToDatabase(userDelete);
        }catch (Exception e){
            logger.error("Error in Process.jatekNemElerheto \n "+e.getMessage());
            return 9;
        }
    }
// Ha valakinek lejárt az ideje akkor átállitja hogy tartozik
    public void searchTartozasok(){
        String sql = "SELECT k.Kolcsonzes_ID, v.Vevo_ID, k.Kolcsonzes_datuma, k.Kolcsonzott_napok FROM vevok v, kikolcsonzott_jatekok k WHERE v.Vevo_ID=k.Felhasznalo_ID AND k.Visszahozas_datuma IS NULL;";
        try {

            ResultSet rs = con.getInfoFromDatabase(sql);
            while(rs.next()) {
                int kolcsID = rs.getInt(1);
                int userID = rs.getInt(2);
                String kolcsDatum = rs.getString(3);
                int napok = rs.getInt(4);

                Date date = new Date();
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
                LocalDate kolcsDate = LocalDate.parse(kolcsDatum);
                LocalDate currDate = LocalDate.parse(formatter.format(date));
                kolcsDate = kolcsDate.plusDays(napok);
                if (kolcsDate.isBefore(currDate)) {
                    setTartozas(userID, kolcsID);
                }
            }
        }catch (Exception e){
            logger.error("Error in Process.searchTartozasok \n "+e.getMessage());
        }
    }
    // Itt állitja magát a tartozást
    public void setTartozas(int userID, int kolcsonID){
        String sql = "UPDATE vevok SET Tartozas = 1 WHERE Vevo_ID="+userID+";";
        String sql2 = "UPDATE kikolcsonzott_jatekok SET Lejart = 1 WHERE Kolcsonzes_ID="+kolcsonID+";";
        con.setInfoToDatabase(sql);
        con.setInfoToDatabase(sql2);
    }
    // az új vevő hozzáadása
    public void setVevo(String felhaszn, String email, LocalDate kor){
        try {
            String sql = "INSERT INTO vevok (Nev, Szuletes_datum, Email_cim, Tartozas) VALUES ('" + felhaszn + "','" + kor + "','" + email + "',0) ;";
            int valasz = con.setInfoToDatabase(sql);
        }catch (Exception e){
            logger.error("Error in Process.setVevo \n "+e.getMessage());
        }
    }
    // ellenőrzi hogy van-e az adott mail-el regelve a kölcsönző
    public boolean countVevo(String vevoEmail){
        boolean isNotRegistered = false;
        try{
            String query = "SELECT COUNT(*) FROM vevok WHERE Email_cim='"+vevoEmail+"';";
            ResultSet result  = con.getInfoFromDatabase(query);
            result.next();
            int count = result.getInt(1);
            if (count <1){
                isNotRegistered = true;
            }
        }catch (SQLException e){
            logger.error("Error in Process.countVevo \n "+e.getMessage());
        }

        return isNotRegistered;
    }
// itt rakja de az adatbázisba az új game-et
    public int[] setJatek(String jatekNev, int ar, String kiado, String kategoria, String platform, int minKor){
        int[] valasz={0, 0};
        String sql = "INSERT INTO jatekok (Nev, Ar, Kiado, Kategoria, Platform, Eletkor, Elerhetoseg) VALUES ('"+jatekNev+"',"+ar+",'"+kiado+"','"+kategoria+"','"+platform+"',"+minKor+",1);";
        String query ="SELECT Vonalkod_ID FROM jatekok WHERE Nev='"+jatekNev+"';";
        con.setInfoToDatabase(sql);
        try{
            ResultSet rs = con.getInfoFromDatabase(query);
            rs.next();
            valasz[1] = rs.getInt(1);
        }catch (Exception e){
            logger.error("Error in Process.setJatek \n "+e.getMessage());
            valasz[0]=99;
            return valasz;
        }
        valasz[0]=40;
        return valasz;
    }
//Megnézi hogy van-e game az adott névvel
    public boolean searchJatek(String jatekNev){
        boolean isNotRegistered = false;
        int count = 0;
        try{
            String query = "SELECT COUNT(*) FROM jatekok WHERE Nev='"+jatekNev+"';";
            ResultSet result  = con.getInfoFromDatabase(query);
            result.next();

            count = result.getInt(1);
            if (count <1){
                isNotRegistered = true;
            }
        }catch (SQLException e){
            logger.error("Error in Process.searchJatek \n "+e.getMessage());
        }

        return isNotRegistered;
    }
// megnézi hogy van-e tartozása a kölcsönzőnek
    public boolean searchTartozas(String vevoEmail){
        boolean tartozik = false;
        try{
            String query = "SELECT Tartozas FROM vevok WHERE Email_cim='"+vevoEmail+"';";
            ResultSet result = con.getInfoFromDatabase(query);
            result.next();
            String tmp = result.getString(1);
            if(tmp.equals("1")){
                tartozik = true;
            }else{
                tartozik=false;
            }

        }catch (SQLException e){
            logger.error("Error in Process.searchTartozas \n "+e.getMessage());
        }

        return tartozik;
    }
    // Usert keres mail alapján
    public int searchUserID(String vevoEmail){
        int userid = -1;
        try{
            String query = "SELECT Vevo_ID FROM vevok WHERE Email_cim='"+vevoEmail+"';";
            ResultSet result =  con.getInfoFromDatabase(query);

            result.next();
            userid = result.getInt(1);

        }catch (SQLException e){
            logger.error("Error in Process.searchUserID \n "+e.getMessage());
        }

        return userid;
    }
    // maga a kölcsönzés
    public boolean kolcsonzes(int UserID, int GameID, int napok) {
        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String sql = "INSERT INTO kikolcsonzott_jatekok (Felhasznalo_ID, Jatek_ID, Kolcsonzes_datuma, Kolcsonzott_napok, Lejart) VALUES ("+UserID+","+GameID+",'"+formatter.format(date)+"',"+napok+",0);";
        boolean valasz = false;
        try {
            con.setInfoToDatabase(sql);

        } catch (Exception e) {
            logger.error("Error in Process.kolcsonzes \n "+e.getMessage());
            return valasz;
        }
        valasz = true;
        return valasz;
    }
    // vissza vitel
    public int visszaVitel(int KolcsonzesID) {

        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

        String sql ="SELECT Felhasznalo_ID FROM kikolcsonzott_jatekok WHERE Kolcsonzes_ID='"+KolcsonzesID+"';";

        String query1 = "UPDATE kikolcsonzott_jatekok SET Lejart = 0 , Visszahozas_datuma='"+formatter.format(date)+"' WHERE Kolcsonzes_ID="+KolcsonzesID+";";
        int valasz = 0;
        int VevoID;
        try {
            ResultSet result =  con.getInfoFromDatabase(sql);

            result.next();
            VevoID = result.getInt(1);

            valasz = con.setInfoToDatabase(query1);

            String sql2 = "SELECT COUNT(*) FROM kikolcsonzott_jatekok WHERE Felhasznalo_ID="+VevoID+" AND Lejart=1;";
            ResultSet result2 = con.getInfoFromDatabase(sql2);
            result2.next();
            int tartozike = result2.getInt(1);
            if(tartozike>0) {
                String query2 = "UPDATE vevok SET Tartozas = 1 WHERE Vevo_ID=" + VevoID + ";";
                valasz = con.setInfoToDatabase(query2);
            }else {
                String query2 = "UPDATE vevok SET Tartozas = 0 WHERE Vevo_ID="+VevoID+";";
                valasz = con.setInfoToDatabase(query2);
            }


        } catch (Exception e) {
            logger.error("Error in Process.visszaVitel \n "+e.getMessage());
            return 91;
        }
        return valasz;
    }
}
