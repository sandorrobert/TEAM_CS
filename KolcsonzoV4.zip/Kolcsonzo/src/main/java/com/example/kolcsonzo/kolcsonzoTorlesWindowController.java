package com.example.kolcsonzo;

import com.example.kolcsonzo.Classes.*;
import com.example.kolcsonzo.Classes.Process;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class kolcsonzoTorlesWindowController implements Initializable {
// Itt kapcsoljuk össze a GUI-t magával a programmal, a müködési logikával. fxml mappák

    Connector connector = new Connector("konzolbolt", "root", "", "localhost");

    public TableView<Users> kolcsonzoTorlesTable;
    public TableColumn<Users, String> colKolcsonzoNev;
    public TableColumn<Users, String> colKolcsonzoEmail;
    public TableColumn<Users, String> colKolcsonzoAktiv;
    public Button kolcsonzoAktivalas;
    public TextField searchKolcsonzoTorlesInput = new TextField();

    ObservableList<Users> usersTorlesList;
    Process proc;

    void searchKolcsonzokTorles(){
        usersTorlesList = proc.getAllUsers();
        colKolcsonzoNev.setCellValueFactory(new PropertyValueFactory<Users,String>("Vevo_Nev"));
        colKolcsonzoEmail.setCellValueFactory(new PropertyValueFactory<Users,String>("Vevo_email"));
        colKolcsonzoAktiv.setCellValueFactory(new PropertyValueFactory<Users,String>("Aktiv"));
        kolcsonzoTorlesTable.setItems(usersTorlesList);


        FilteredList<Users> jatekokFilter =new FilteredList<>(usersTorlesList, b -> true);

        searchKolcsonzoTorlesInput.textProperty().addListener((observable, oldvalue, newvalue) -> {
            jatekokFilter.setPredicate(Users -> {

                if (newvalue.isEmpty() || newvalue.isBlank() || newvalue == null){
                    return true;
                }
                String searchKeyWord = newvalue.toLowerCase();

                if(Users.getVevo_Nev().toLowerCase().contains(searchKeyWord)){
                    return true;
                }else if(Users.getVevo_email().toLowerCase().contains(searchKeyWord)){
                    return true;
                }else if(Users.getAktiv().toLowerCase().contains(searchKeyWord)){
                return true;
                }else{
                    return false;
                }

            });
        });

        SortedList<Users> jatekokSorted = new SortedList<>(jatekokFilter);
        jatekokSorted.comparatorProperty().bind(kolcsonzoTorlesTable.comparatorProperty());
        kolcsonzoTorlesTable.setItems(jatekokSorted);
    }

    public void onKolcsonzoTorles(){
        int temp = kolcsonzoTorlesTable.getSelectionModel().getSelectedIndex();
        if(temp>=0){
            Users user = kolcsonzoTorlesTable.getSelectionModel().getSelectedItem();
            if(user.getAktiv().equals("Aktív")){
                int valasz = proc.kolcsonzoDeaktivalas(user.getVevo_ID());
                if(valasz ==1){
                    ButtonType yesButtonType = new ButtonType("Igen", ButtonBar.ButtonData.OK_DONE);
                    ButtonType noButtonType = new ButtonType("Nem", ButtonBar.ButtonData.CANCEL_CLOSE);
                    Alert alert = new Alert(Alert.AlertType.INFORMATION,
                                    user.getVevo_Nev()+" sikeresen deaktiválva. \n Kíván más felhasználót is deaktiválni?",
                                    yesButtonType,
                                    noButtonType);

                    alert.setHeaderText("Siker");
                    alert.setTitle("Siker");
                    Optional<ButtonType> result = alert.showAndWait();
                    if (result.orElse(yesButtonType) == noButtonType) {
                        onKilepes();
                    }else{
                        searchKolcsonzokTorles();
                    }
                }else if(valasz ==8){
                    Alert alert = new Alert(Alert.AlertType.ERROR,user.getVevo_Nev()+" felhasználónak még van aktív kölcsönzése.");
                    alert.setHeaderText("Hiba");
                    alert.setTitle("Hiba");
                    alert.showAndWait();
                }else{
                    Alert alert = new Alert(Alert.AlertType.ERROR,"Hiba a folyamatban.");
                    alert.setHeaderText("Hiba");
                    alert.setTitle("Hiba");
                    alert.showAndWait();
                }
            }else{
                int valasz = proc.kolcsonzoAktivalas(user.getVevo_ID());
                if(valasz ==1){
                    ButtonType yesButtonType = new ButtonType("Igen", ButtonBar.ButtonData.OK_DONE);
                    ButtonType noButtonType = new ButtonType("Nem", ButtonBar.ButtonData.CANCEL_CLOSE);
                    Alert alert = new Alert(Alert.AlertType.INFORMATION,
                            user.getVevo_Nev()+" sikeresen aktiválva. \n Kíván más felhasználót is aktiválni?",
                            yesButtonType,
                            noButtonType);
                    alert.setHeaderText("Siker");
                    alert.setTitle("Siker");
                    Optional<ButtonType> result = alert.showAndWait();
                    if (result.orElse(yesButtonType) == noButtonType) {
                        onKilepes();
                    }else{
                        searchKolcsonzokTorles();
                    }
                }else{
                    Alert alert = new Alert(Alert.AlertType.ERROR,"Hiba a folyamatban.");
                    alert.setHeaderText("Hiba");
                    alert.setTitle("Hiba");
                    alert.showAndWait();
                }
            }
        }else{
            Alert alert = new Alert(Alert.AlertType.ERROR,"Nincs kölcsönző kiválasztva.");
            alert.setHeaderText("Hiba");
            alert.setTitle("Hiba");
            alert.showAndWait();
        }
    }

    protected void onKilepes(){
        connector.stopConnection();
        Stage stage = (Stage) kolcsonzoAktivalas.getScene().getWindow();
        stage.close();
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        proc = new Process(connector);
        searchKolcsonzoTorlesInput.setPromptText("Keresés");
        searchKolcsonzokTorles();
    }
}
