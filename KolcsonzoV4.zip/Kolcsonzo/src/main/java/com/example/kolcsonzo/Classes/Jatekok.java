package com.example.kolcsonzo.Classes;

// Innen fogja a játékokat példányositani

public class Jatekok {
    int Vonalkod, korhatar;
    private String nev;
    private String Kategoria;
    private String Platform;
    private String Elerhetoseg;

    public Jatekok(int id, String Nev, int kor, String platform, String Kateg, boolean elerhet){
        Vonalkod = id;
        nev = Nev;
        korhatar = kor;
        Platform = platform;
        Kategoria = Kateg;
        if(elerhet){
            Elerhetoseg = "Elérhető";
        }else{
            Elerhetoseg = "Nem elérhető";
        }
    }

    public String getPlatform() {
        return Platform;
    }

    public String getKategoria() {
        return Kategoria;
    }

    public String getNev() {
        return nev;
    }

    public int getKorhatar() {
        return korhatar;
    }

    public String getElerhetoseg() {
        return Elerhetoseg;
    }

    public int getVonalkod() {
        return Vonalkod;
    }
}
