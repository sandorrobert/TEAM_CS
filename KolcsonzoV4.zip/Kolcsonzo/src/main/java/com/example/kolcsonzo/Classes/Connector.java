package com.example.kolcsonzo.Classes;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

// összeköti az SQL és a progit

public class Connector {
    private static final Logger logger = LogManager.getLogger(Process.class);
    Connection con = null;

    public Connector(String database, String username, String password, String ipAddress){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://"+ipAddress+":3306/"+database+"",username,password);


        }catch(SQLException | ClassNotFoundException e){
            logger.error("Error in connector "+ e.getStackTrace());
        }
    }

    public void stopConnection(){
        try{
            con.close();
        }
        catch(SQLException e){
            logger.error("Error in stopconnector "+ e.getStackTrace());
        }
    }

    public ResultSet getInfoFromDatabase(String sqlQuery) {
        ResultSet rs = null;
        try {
            Statement stmt = con.createStatement();
            rs = stmt.executeQuery(sqlQuery);
        } catch (SQLException e) {
            logger.error("Error in getInfoFromDatabase "+ e.getStackTrace());
        }
        return rs;
    }

    public int setInfoToDatabase(String sqlQuery) {
        int valasz = 0;
        try {
            Statement stmt = con.createStatement();
            valasz = stmt.executeUpdate(sqlQuery);
        } catch (SQLException e) {
            logger.error("Error in setInfoToDatabase "+ e.getStackTrace());
        }
        return valasz;
    }

}