module com.example.konzolbolt {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires org.kordamp.bootstrapfx.core;

    opens com.example.konzolbolt to javafx.fxml;
    exports com.example.konzolbolt;
}